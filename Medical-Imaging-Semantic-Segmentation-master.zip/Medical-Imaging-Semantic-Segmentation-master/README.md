# Medical Imaging Semantic Segmentation - Nuclie Segmentation using UNet and ICNet implementations in Tensorflow 2
- This repository contains UNet and ICNet implementations for semantic segmentation of nuclei images, from [Kaggle's 2018 Data Science Bowl](https://www.kaggle.com/c/data-science-bowl-2018/data)
